from PyQt5 import QtCore, QtGui, QtWidgets

"""
    Класс в котором:
    - Инициализируется окно приложения.
    - Инициализируются виджеты PyQt5.
    - Размещается интерфейс.
    - Кнопки привязывается к функциям.
"""


class Ui_CaculatorWin(object):
    def setupUi(self, CaculatorWin):

        # Инициализация окна приложения.

        CaculatorWin.setObjectName("CaculatorWin")
        CaculatorWin.resize(340, 315)
        CaculatorWin.setMinimumSize(QtCore.QSize(340, 315))
        CaculatorWin.setMaximumSize(QtCore.QSize(340, 315))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("../../../jwp/Ресурсы/cal.jpg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        CaculatorWin.setWindowIcon(icon)
        self.row_lable = ["Запрос", "Ответ"]

        # Инициализация виджетов PyQt5 и размещение интерфейса.

        self.tabWidget = QtWidgets.QTabWidget(CaculatorWin)
        self.tabWidget.setGeometry(QtCore.QRect(6, -1, 331, 311))
        self.tabWidget.setObjectName("tabWidget")
        self.tab = QtWidgets.QWidget()
        self.tab.setObjectName("tab")

        self.CalculatorDisplay = QtWidgets.QTextBrowser(self.tab)
        self.CalculatorDisplay.setGeometry(QtCore.QRect(10, 10, 301, 81))
        self.CalculatorDisplay.setObjectName("CalculatorDisplay")

        self.gridLayoutWidget = QtWidgets.QWidget(self.tab)
        self.gridLayoutWidget.setGeometry(QtCore.QRect(9, 110, 301, 170))
        self.gridLayoutWidget.setObjectName("gridLayoutWidget")

        self.gridLayout_2 = QtWidgets.QGridLayout(self.gridLayoutWidget)
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_2.setObjectName("gridLayout_2")

        self.pushButton_dot = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton_dot.setObjectName("pushButton_dot")

        self.gridLayout_2.addWidget(self.pushButton_dot, 2, 3, 1, 1)

        self.pushButton_Multiply = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton_Multiply.setObjectName("pushButton_Multiply")

        self.gridLayout_2.addWidget(self.pushButton_Multiply, 0, 2, 1, 1)

        self.pushButton0 = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton0.setObjectName("pushButton0")

        self.gridLayout_2.addWidget(self.pushButton0, 6, 0, 1, 1)

        self.pushButton_div = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton_div.setObjectName("pushButton_div")

        self.gridLayout_2.addWidget(self.pushButton_div, 0, 3, 1, 1)

        self.pushButton_leftbrackets = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton_leftbrackets.setObjectName("pushButton_leftbrackets")

        self.gridLayout_2.addWidget(self.pushButton_leftbrackets, 6, 1, 1, 1)

        self.pushButton5 = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton5.setObjectName("pushButton5")

        self.gridLayout_2.addWidget(self.pushButton5, 3, 1, 1, 1)

        self.pushButton_mod = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton_mod.setObjectName("pushButton_mod")

        self.gridLayout_2.addWidget(self.pushButton_mod, 3, 3, 1, 1)

        self.pushButton3 = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton3.setObjectName("pushButton3")

        self.gridLayout_2.addWidget(self.pushButton3, 2, 2, 1, 1)

        self.pushButton_Add = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton_Add.setObjectName("pushButton_Add")

        self.gridLayout_2.addWidget(self.pushButton_Add, 0, 0, 1, 1)

        self.pushButton1 = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton1.setObjectName("pushButton1")

        self.gridLayout_2.addWidget(self.pushButton1, 2, 0, 1, 1)

        self.pushButton9 = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton9.setObjectName("pushButton9")

        self.gridLayout_2.addWidget(self.pushButton9, 4, 2, 1, 1)

        self.pushButton8 = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton8.setObjectName("pushButton8")

        self.gridLayout_2.addWidget(self.pushButton8, 4, 1, 1, 1)

        self.pushButton_rightbrackets = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton_rightbrackets.setObjectName("pushButton_rightbrackets")

        self.gridLayout_2.addWidget(self.pushButton_rightbrackets, 6, 2, 1, 1)

        self.pushButton6 = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton6.setObjectName("pushButton6")

        self.gridLayout_2.addWidget(self.pushButton6, 3, 2, 1, 1)

        self.pushButton4 = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton4.setObjectName("pushButton4")

        self.gridLayout_2.addWidget(self.pushButton4, 3, 0, 1, 1)

        self.pushButton2 = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton2.setObjectName("pushButton2")

        self.gridLayout_2.addWidget(self.pushButton2, 2, 1, 1, 1)

        self.pushButton_Minus = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton_Minus.setObjectName("pushButton_Minus")

        self.gridLayout_2.addWidget(self.pushButton_Minus, 0, 1, 1, 1)

        self.pushButton7 = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton7.setObjectName("pushButton7")

        self.gridLayout_2.addWidget(self.pushButton7, 4, 0, 1, 1)

        self.pushButton_Cal = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton_Cal.setObjectName("pushButton_Cal")

        self.gridLayout_2.addWidget(self.pushButton_Cal, 6, 3, 1, 1)

        self.pushButton_Clear = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton_Clear.setObjectName("pushButton_Clear")

        self.gridLayout_2.addWidget(self.pushButton_Clear, 4, 3, 1, 1)

        self.tabWidget.addTab(self.tab, "")

        self.tab_2 = QtWidgets.QWidget()
        self.tab_2.setObjectName("tab_2")

        self.pushButton = QtWidgets.QPushButton(self.tab_2)
        self.pushButton.setGeometry(QtCore.QRect(4, 250, 311, 31))
        self.pushButton.setObjectName("pushButton")

        self.tableWidget = QtWidgets.QTableWidget(self.tab_2)
        self.tableWidget.setGeometry(QtCore.QRect(5, 11, 311, 231))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(2)
        self.tableWidget.setRowCount(0)
        self.tableWidget.setHorizontalHeaderLabels(self.row_lable)

        self.tabWidget.addTab(self.tab_2, "")

        self.retranslateUi(CaculatorWin)
        self.tabWidget.setCurrentIndex(1)

        # Привязка кнопок к функциям.

        self.pushButton_Add.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton_Minus.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton_Multiply.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton_div.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton1.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton2.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton3.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton_dot.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton4.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton5.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton6.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton_mod.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton7.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton8.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton9.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton0.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton_leftbrackets.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton_rightbrackets.clicked.connect(CaculatorWin.CalObjPressed)  # type: ignore
        self.pushButton_Cal.clicked.connect(CaculatorWin.ExecuteCalculate)  # type: ignore
        self.pushButton_Clear.clicked.connect(CaculatorWin.ClearInput)  # type: ignore
        self.pushButton.clicked.connect(CaculatorWin.Update_Result)  # type: ignore
        QtCore.QMetaObject.connectSlotsByName(CaculatorWin)

    def retranslateUi(self, CaculatorWin):

        # Определяется значение каждой кнопки.

        _translate = QtCore.QCoreApplication.translate
        CaculatorWin.setWindowTitle(_translate("CaculatorWin", "Калькулятор"))
        self.pushButton_dot.setText(_translate("CaculatorWin", "."))
        self.pushButton_Multiply.setText(_translate("CaculatorWin", " * "))
        self.pushButton0.setText(_translate("CaculatorWin", "0"))
        self.pushButton_div.setText(_translate("CaculatorWin", " / "))
        self.pushButton_leftbrackets.setText(_translate("CaculatorWin", "("))
        self.pushButton5.setText(_translate("CaculatorWin", "5"))
        self.pushButton_mod.setText(_translate("CaculatorWin", " % "))
        self.pushButton3.setText(_translate("CaculatorWin", "3"))
        self.pushButton_Add.setText(_translate("CaculatorWin", " + "))
        self.pushButton1.setText(_translate("CaculatorWin", "1"))
        self.pushButton9.setText(_translate("CaculatorWin", "9"))
        self.pushButton8.setText(_translate("CaculatorWin", "8"))
        self.pushButton_rightbrackets.setText(_translate("CaculatorWin", ")"))
        self.pushButton6.setText(_translate("CaculatorWin", "6"))
        self.pushButton4.setText(_translate("CaculatorWin", "4"))
        self.pushButton2.setText(_translate("CaculatorWin", "2"))
        self.pushButton_Minus.setText(_translate("CaculatorWin", " - "))
        self.pushButton7.setText(_translate("CaculatorWin", "7"))
        self.pushButton_Cal.setText(_translate("CaculatorWin", "="))
        self.pushButton_Clear.setText(_translate("CaculatorWin", "Clear"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), _translate("CaculatorWin", "Калькулятор"))
        self.pushButton.setText(_translate("CaculatorWin", "Обновить результаты"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), _translate("CaculatorWin", "История"))

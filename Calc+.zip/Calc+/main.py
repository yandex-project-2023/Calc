import sys
from PyQt5 import QtWidgets
from ui_Calculator import Ui_CaculatorWin
import sqlite3

db_request, db_result = str(), str()

# Основной класс программмы.


class Calculator(QtWidgets.QWidget, Ui_CaculatorWin):

    # Инициализация классса и подключение к базе данных.

    def __init__(self):
        super(Calculator, self).__init__()
        self.con = sqlite3.connect("Results.sqlite")
        self.setupUi(self)
        self.expression = ''
        self.resultfinished = False

    # Вывод нажатого символа на экран.

    def CalObjPressed(self):
        global db_request
        if self.resultfinished:
            self.ClearInput()
        pbutton = self.sender()
        character = pbutton.text()
        db_request += character
        self.CalculatorDisplay.insertPlainText(character)
        self.expression += character

    # Вычисление результата и обработка ошибок.

    def ExecuteCalculate(self):
        global db_result, db_request

        if "()" in db_request:
            db_request = db_request[2::]
        self.CalculatorDisplay.append("=")
        global_area = {}
        try:
            result = eval(self.expression, global_area)
            db_result = result
        except Exception as e:
            self.CalculatorDisplay.append(f"Результат расчета неверен, причина ошибки: \n - {str(e).capitalize()}")
        else:
            self.CalculatorDisplay.append(str(result))

        self.resultfinished = True

        self.AddDataToTable(db_request, db_result)

        db_result, db_request = "", ""

    # Очищение ввода.

    def ClearInput(self):
        self.CalculatorDisplay.clear()
        self.expression = ''
        self.resultfinished = False

    # Добавление выражения и результата в базу данных.

    def AddDataToTable(self, req, res):
        cur = self.con.cursor()
        data = req, res
        cur.execute(f"""INSERT INTO Results (Req, Res) VALUES (?, ?)""", data)
        self.con.commit()

    # Обновление истории запросов.

    def Update_Result(self):
        cur = self.con.cursor()
        results = cur.execute("SELECT * FROM Results").fetchall()

        row = len(results)
        self.tableWidget.setRowCount(row)

        for i, elem in enumerate(results):
            for j, val in enumerate(elem):
                if j == 1 and val == "":
                    self.tableWidget.setItem(i, j, QtWidgets.QTableWidgetItem("Ошибка"))
                else:
                    self.tableWidget.setItem(i, j, QtWidgets.QTableWidgetItem(str(val)))
        self.modified = {}

# Вывод скрытых ошибок PyQt5.


def except_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)

# Код запуска программы.


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    W = Calculator()
    W.show()
    sys.excepthook = except_hook
    sys.exit(app.exec_())
